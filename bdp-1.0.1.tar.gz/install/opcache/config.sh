
old_dir='/home/yeshiquan/bdp/output'
binary_files=()
text_files=(
    php/etc/ext/opcache.ini
)
macro_files=(
    conf
)
macros=(
    'BDP_ONLINE'
)
