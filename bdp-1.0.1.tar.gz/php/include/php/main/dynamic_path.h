/***************************************************************************
 * 
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 * 
 **************************************************************************/



/**
 * @file dynamic_path.h
 * @author wangweibing(wangweibing@baidu.com)
 * @date 2014/09/19 14:14:45
 * @brief patch php，实现任意路径安装
 *  
 **/

#ifndef DYNAMIC_PATH_H
#define DYNAMIC_PATH_H

extern char __ini_path[];
extern char __ini_scan_path[];

char* __get_dynamic_path_from_compile_path(char* compile_path);
char* __get_dynamic_path_from_relative_path(char* relative_path, char *dest);

#endif //DYNAMIC_PATH_H

/***************************************************************************
 * 
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 * 
 **************************************************************************/



/**
 * @file dynamic_path.h
 * @author wangweibing(wangweibing@baidu.com)
 * @date 2014/09/19 14:14:45
 * @brief patch php，实现任意路径安装
 *  
 **/

#ifndef DYNAMIC_PATH_H
#define DYNAMIC_PATH_H

extern char __ini_path[];
extern char __ini_scan_path[];

char* __get_dynamic_path_from_compile_path(char* compile_path);
char* __get_dynamic_path_from_relative_path(char* relative_path, char *dest);

#endif //DYNAMIC_PATH_H

