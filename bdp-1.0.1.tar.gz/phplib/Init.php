<?php

/**
 *
 * BDP全局初始化类。
 * @author yeshiquan(yeshiquan@baidu.com)
 *
 */

class BdpInit
{
    static private $isInit = false;

    /**
     * init
     * @param
     * @return
     */
    public static function init() {
        if(self::$isInit) {
            return false;
        }

        self::$isInit = true;

        // 设置默认timezone，避免PHP5.4或HHVM报warning
        date_default_timezone_set('PRC');
        self::initEnv();
        //self::initLibClass();
    }

    /**
     * initBasicEnv
     * @param
     * @return
     */
    private static function initEnv() {
        // 页面启动时间(us)，PHP5.4可用$_SERVER['REQUEST_TIME']
        define('REQUEST_TIME_US', intval(microtime(true)*1000000));

        // BDP预定义路径
        define('ROOT_PATH', realpath(dirname(__FILE__) . '/../'));
        define('CONF_PATH', ROOT_PATH.'/conf');
        define('DATA_PATH', ROOT_PATH.'/data');
        define('BIN_PATH', ROOT_PATH.'/php/bin');
        define('LOG_PATH', ROOT_PATH.'/log');
        define('LIB_PATH', ROOT_PATH.'/phplib');
        define('PHP_EXEC', BIN_PATH.'/php');

        return true;
    }
}

BdpInit::init();
