
old_dir='/home/yeshiquan/bdp/output'
binary_files=()
text_files=(
    conf
)
macro_files=(
    conf
)
macros=(
    'BDP_ONLINE'
)
