#!/bin/bash

set -e

source $(cd `dirname $0`/../ && pwd)/bin/env.sh

NGINX_HOME=${BDP_ROOT}/webserver
NGINX_BIN=$NGINX_HOME/sbin/nginx
PID_FILE=${BDP_ROOT}/var/nginx.pid
NGINX_LOG="access_log error_log"

#/etc/rc.d/init.d/functions

cd $NGINX_HOME/sbin

start() {
    echo -n "Starting nginx: "
    
    if [ ! -d "${BDP_ROOT}/log/webserver" ]
    then
        mkdir "${BDP_ROOT}/log/webserver"
    fi

    for i in $NGINX_LOG
    do
        if [ ! -f "${BDP_ROOT}/log/webserver/$i" ] ; then
            touch "${BDP_ROOT}/log/webserver/$i"
        fi
        if [ ! -h "${BDP_ROOT}/log/$i" ] ; then
            ln -s "webserver/$i" "${BDP_ROOT}/log/$i"
        fi
    done
    
    if GCONV_PATH=$BDP_GCONV_PATH $NGINX_BIN </dev/null; then
        echo "ok"
    else
        echo "fail"
    fi
}

stop() {
    if [[ ! -f $PID_FILE ]]; then
        return
    fi
    PID=`head $PID_FILE`
    if ! process_exists $PID $NGINX_BIN; then
        rm $PID_FILE
        return
    fi
    echo -n "Stopping nginx: "
    # when nginx.conf error, nginx -s stop will failed
    #GCONV_PATH=$BDP_GCONV_PATH $NGINX_BIN -s stop
    kill $PID
    if wait_for 10 "not process_exists $PID $NGINX_BIN"; then
        echo 'ok'
    else
        echo 'fail'
        exit 1
    fi
}


case "$1" in
start)
    stop
    start
    ;;

stop)
    stop
    ;;

restart)
    stop
    start
    ;;

reload)
    if GCONV_PATH=$BDP_GCONV_PATH $NGINX_BIN -s reload; then
        echo  "reload ok, please check it youself";
    else
        echo "reload fail"
    fi
    ;;

chkconfig)
    GCONV_PATH=$BDP_GCONV_PATH $NGINX_BIN -t
    ;;

*)
echo "Usage: $0 {start|stop|restart|chkconfig|reload}"
exit 1
esac
