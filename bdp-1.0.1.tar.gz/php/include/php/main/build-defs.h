/*                                                                -*- C -*-
   +----------------------------------------------------------------------+
   | PHP Version 5                                                        |
   +----------------------------------------------------------------------+
   | Copyright (c) 1997-2007 The PHP Group                                |
   +----------------------------------------------------------------------+
   | This source file is subject to version 3.01 of the PHP license,      |
   | that is bundled with this package in the file LICENSE, and is        |
   | available through the world-wide-web at the following url:           |
   | http://www.php.net/license/3_01.txt                                  |
   | If you did not receive a copy of the PHP license and are unable to   |
   | obtain it through the world-wide-web, please send a note to          |
   | license@php.net so we can mail you a copy immediately.               |
   +----------------------------------------------------------------------+
   | Author: Stig S�ther Bakken <ssb@php.net>                             |
   +----------------------------------------------------------------------+
*/

/* $Id$ */

#define CONFIGURE_COMMAND " './configure'  '--prefix=/home/yeshiquan/bdp/output/php' '--with-config-file-path=/home/yeshiquan/bdp/output/php/etc' '--with-config-file-scan-dir=/home/yeshiquan/bdp/output/php/etc/ext' '--enable-fpm' '--enable-bcmath' '--enable-mbstring' '--enable-shmop' '--enable-soap' '--enable-sockets' '--enable-exif' '--enable-ftp' '--enable-sysvsem' '--enable-pcntl' '--enable-wddx' '--enable-zip' '--with-pear' '--with-t1lib=/home/yeshiquan/bdp/dep/t1lib' '--with-mcrypt=/home/yeshiquan/bdp/dep/libmcrypt' '--with-openssl=/home/yeshiquan/bdp/dep/openssl' '--with-zlib=/home/yeshiquan/bdp/dep/zlib' '--with-libxml-dir=/home/yeshiquan/bdp/dep/libxml2/bin/xml2-config' '--with-curl=/home/yeshiquan/bdp/dep/curl' '--with-jpeg-dir=/home/yeshiquan/bdp/dep/libjpeg' '--with-png-dir=/home/yeshiquan/bdp/dep/libpng' '--with-freetype-dir=/home/yeshiquan/bdp/dep/freetype' '--with-mhash=/home/yeshiquan/bdp/dep/mhash' '--with-mysql=mysqlnd' '--with-mysqli=mysqlnd' '--with-pdo-mysql=mysqlnd' '--with-iconv' '--with-gd' '--enable-gd-native-ttf'"
#define PHP_ADA_INCLUDE		""
#define PHP_ADA_LFLAGS		""
#define PHP_ADA_LIBS		""
#define PHP_APACHE_INCLUDE	""
#define PHP_APACHE_TARGET	""
#define PHP_FHTTPD_INCLUDE      ""
#define PHP_FHTTPD_LIB          ""
#define PHP_FHTTPD_TARGET       ""
#define PHP_CFLAGS		"$(CFLAGS_CLEAN) -prefer-non-pic -static"
#define PHP_DBASE_LIB		""
#define PHP_BUILD_DEBUG		""
#define PHP_GDBM_INCLUDE	""
#define PHP_IBASE_INCLUDE	""
#define PHP_IBASE_LFLAGS	""
#define PHP_IBASE_LIBS		""
#define PHP_IFX_INCLUDE		""
#define PHP_IFX_LFLAGS		""
#define PHP_IFX_LIBS		""
#define PHP_INSTALL_IT		""
#define PHP_IODBC_INCLUDE	""
#define PHP_IODBC_LFLAGS	""
#define PHP_IODBC_LIBS		""
#define PHP_MSQL_INCLUDE	""
#define PHP_MSQL_LFLAGS		""
#define PHP_MSQL_LIBS		""
#define PHP_MYSQL_INCLUDE	""
#define PHP_MYSQL_LIBS		""
#define PHP_MYSQL_TYPE		""
#define PHP_ODBC_INCLUDE	""
#define PHP_ODBC_LFLAGS		""
#define PHP_ODBC_LIBS		""
#define PHP_ODBC_TYPE		""
#define PHP_OCI8_SHARED_LIBADD 	""
#define PHP_OCI8_DIR			""
#define PHP_OCI8_ORACLE_VERSION		""
#define PHP_ORACLE_SHARED_LIBADD 	"@ORACLE_SHARED_LIBADD@"
#define PHP_ORACLE_DIR				"@ORACLE_DIR@"
#define PHP_ORACLE_VERSION			"@ORACLE_VERSION@"
#define PHP_PGSQL_INCLUDE	""
#define PHP_PGSQL_LFLAGS	""
#define PHP_PGSQL_LIBS		""
#define PHP_PROG_SENDMAIL	"/usr/sbin/sendmail"
#define PHP_SOLID_INCLUDE	""
#define PHP_SOLID_LIBS		""
#define PHP_EMPRESS_INCLUDE	""
#define PHP_EMPRESS_LIBS	""
#define PHP_SYBASE_INCLUDE	""
#define PHP_SYBASE_LFLAGS	""
#define PHP_SYBASE_LIBS		""
#define PHP_DBM_TYPE		""
#define PHP_DBM_LIB		""
#define PHP_LDAP_LFLAGS		""
#define PHP_LDAP_INCLUDE	""
#define PHP_LDAP_LIBS		""
#define PHP_BIRDSTEP_INCLUDE     ""
#define PHP_BIRDSTEP_LIBS        ""
#define PEAR_INSTALLDIR         "/home/yeshiquan/bdp/output/php/lib/php"
#define PHP_INCLUDE_PATH	".:/home/yeshiquan/bdp/output/php/lib/php"
#define PHP_EXTENSION_DIR       "/home/yeshiquan/bdp/output/php/ext"
#define PHP_PREFIX              "/home/yeshiquan/bdp/output/php"
#define PHP_BINDIR              "/home/yeshiquan/bdp/output/php/bin"
#define PHP_SBINDIR             "/home/yeshiquan/bdp/output/php/sbin"
#define PHP_MANDIR              "/home/yeshiquan/bdp/output/php/php/man"
#define PHP_LIBDIR              "/home/yeshiquan/bdp/output/php/lib/php"
#define PHP_DATADIR             "${prefix}/share"
#define PHP_SYSCONFDIR          "/home/yeshiquan/bdp/output/php/etc"
#define PHP_LOCALSTATEDIR       "/home/yeshiquan/bdp/output/php/var"
#define PHP_CONFIG_FILE_PATH    "/home/yeshiquan/bdp/output/php/etc"
#define PHP_CONFIG_FILE_SCAN_DIR    "/home/yeshiquan/bdp/output/php/etc/ext"
#define PHP_SHLIB_SUFFIX        "so"

#ifdef PHP_CONFIG_FILE_PATH

#include "dynamic_path.h"

// 从相对路径读取php_ini

#undef PHP_CONFIG_FILE_PATH
#define PHP_CONFIG_FILE_PATH __get_dynamic_path_from_relative_path("etc", __ini_path)

#undef PHP_CONFIG_FILE_SCAN_DIR
#define PHP_CONFIG_FILE_SCAN_DIR __get_dynamic_path_from_relative_path("etc/ext", __ini_scan_path)

#endif //PHP_CONFIG_FILE_PATH
